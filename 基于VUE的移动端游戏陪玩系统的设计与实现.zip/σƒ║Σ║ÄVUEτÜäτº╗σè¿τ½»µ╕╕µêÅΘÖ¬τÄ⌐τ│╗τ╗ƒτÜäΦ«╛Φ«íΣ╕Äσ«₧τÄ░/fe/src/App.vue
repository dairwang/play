<template>
  <div class="min-h-screen bg-dark w-full overflow-x-hidden">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
