const Game = require('../models/game');
const { Op } = require('sequelize');

// Get game list (with search)
exports.getGames = async (req, res) => {
    try {
        const { keyword } = req.query;
        const where = {};
        if (keyword) {
            where.name = { [Op.like]: `%${keyword}%` };
        }

        const games = await Game.findAll({
            where,
            order: [['created_at', 'DESC']]
        });
        
        res.json({ code: 200, data: games });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Create game
exports.createGame = async (req, res) => {
    try {
        const { name, icon, cover } = req.body;
        if (!name) {
            return res.status(400).json({ code: 400, msg: 'Game name is required' });
        }

        const game = await Game.create({ name, icon, cover });
        res.status(201).json({ code: 200, msg: 'Game created successfully', data: game });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Update game
exports.updateGame = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, icon, cover } = req.body;

        const game = await Game.findByPk(id);
        if (!game) {
            return res.status(404).json({ code: 404, msg: 'Game not found' });
        }

        await game.update({ name, icon, cover });
        res.json({ code: 200, msg: 'Game updated successfully', data: game });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Delete game
exports.deleteGame = async (req, res) => {
    try {
        const { id } = req.params;
        const game = await Game.findByPk(id);
        
        if (!game) {
            return res.status(404).json({ code: 404, msg: 'Game not found' });
        }

        await game.destroy();
        res.json({ code: 200, msg: 'Game deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};
