const Order = require('../models/order');
const User = require('../models/user');
const Game = require('../models/game');
const { v4: uuidv4 } = require('uuid');
const { Op } = require('sequelize');

// Create Order (User)
exports.createOrder = async (req, res) => {
    try {
        const { companion_id, game_id, amount, remark } = req.body;
        const user_id = req.user.id;

        // Simple validation: cannot order self
        if (user_id === companion_id) {
            return res.status(400).json({ code: 400, msg: 'Cannot order yourself' });
        }

        const order = await Order.create({
            order_no: uuidv4().replace(/-/g, ''),
            user_id,
            companion_id,
            game_id,
            amount,
            remark,
            status: 'pending'
        });

        res.status(201).json({ code: 200, msg: 'Order created', data: order });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Get My Orders (User/Companion)
exports.getMyOrders = async (req, res) => {
    try {
        const user_id = req.user.id;
        const { role } = req.query; // 'client' or 'companion'

        const where = role === 'companion' ? { companion_id: user_id } : { user_id };

        const orders = await Order.findAll({
            where,
            include: [
                { model: User, as: 'Client', attributes: ['nickname', 'avatar'] },
                { model: User, as: 'Companion', attributes: ['nickname', 'avatar'] },
                { model: Game, attributes: ['name', 'icon'] }
            ],
            order: [['created_at', 'DESC']]
        });

        res.json({ code: 200, data: orders });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Accept Order (Companion)
exports.acceptOrder = async (req, res) => {
    try {
        const { id } = req.params;
        const user_id = req.user.id;

        const order = await Order.findOne({ where: { id, companion_id: user_id } });
        if (!order) {
            return res.status(404).json({ code: 404, msg: 'Order not found' });
        }

        if (order.status !== 'pending') {
            return res.status(400).json({ code: 400, msg: 'Order status invalid' });
        }

        order.status = 'accepted';
        await order.save();

        res.json({ code: 200, msg: 'Order accepted' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Complete Order (User)
exports.completeOrder = async (req, res) => {
    try {
        const { id } = req.params;
        const user_id = req.user.id;

        // Only client can complete? Or companion? Usually client confirms.
        const order = await Order.findOne({ where: { id, user_id } });
        if (!order) {
            return res.status(404).json({ code: 404, msg: 'Order not found' });
        }

        if (order.status !== 'accepted') {
            return res.status(400).json({ code: 400, msg: 'Order status invalid' });
        }

        order.status = 'completed';
        order.completed_at = new Date();
        await order.save();
        
        // Transfer money: Client -> Companion
        // Note: In a real system, we should use a transaction and check balance first.
        const client = await User.findByPk(order.user_id);
        const companion = await User.findByPk(order.companion_id);
        
        if (client && companion) {
            client.balance = Number(client.balance) - Number(order.amount);
            companion.balance = Number(companion.balance) + Number(order.amount);
            await client.save();
            await companion.save();
        }

        res.json({ code: 200, msg: 'Order completed' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Cancel Order (User/Companion)
exports.cancelOrder = async (req, res) => {
    try {
        const { id } = req.params;
        const user_id = req.user.id;

        const order = await Order.findOne({ 
            where: { 
                id, 
                [Op.or]: [{ user_id }, { companion_id: user_id }]
            } 
        });

        if (!order) {
            return res.status(404).json({ code: 404, msg: 'Order not found' });
        }

        if (order.status !== 'pending') {
            return res.status(400).json({ code: 400, msg: 'Cannot cancel accepted orders' });
        }

        order.status = 'cancelled';
        await order.save();

        res.json({ code: 200, msg: 'Order cancelled' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};

// Get All Orders (Admin)
exports.getAllOrders = async (req, res) => {
    try {
        const { keyword } = req.query;
        // In real app, keyword could search order_no or user name
        const where = {};
        if (keyword) {
            where.order_no = { [Op.like]: `%${keyword}%` };
        }

        const orders = await Order.findAll({
            where,
            include: [
                { model: User, as: 'Client', attributes: ['nickname'] },
                { model: User, as: 'Companion', attributes: ['nickname'] },
                { model: Game, attributes: ['name'] }
            ],
            order: [['created_at', 'DESC']]
        });

        res.json({ code: 200, data: orders });
    } catch (error) {
        console.error(error);
        res.status(500).json({ code: 500, msg: 'Server error' });
    }
};
